export interface etapes {
    eta_id: string;
    eta_idTra:string;
    eta_ville:string;
}