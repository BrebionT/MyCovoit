export interface trajets {
    tra_id: string;
    tra_heureDepart: string;
    tra_heureArrivee: string;
    tra_lieuDepart: string;
    tra_villeArrivee: string;
    tra_villeDepart: string;
    tra_lieuArrivee: string;
    tra_dateDepart: string;
    tra_nbPlaces: number;
    tra_etape: string;
    uti_tra_idtra: string;
}
