export interface utilisateur_trajet {
    uti_tra_idUti: string;
    uti_tra_idTra:string;
    uti_tra_role:string;
}
